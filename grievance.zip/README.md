# college
Enquire and suggestion page of GEC, Bhojpur
